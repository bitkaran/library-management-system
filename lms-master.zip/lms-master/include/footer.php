<script src="<?php echo BASE_URL ?>assets/js/jquery-3.5.1.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/dataTables.bootstrap5.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        $('#data-table').DataTable();
    });
</script>
</body>

</html>